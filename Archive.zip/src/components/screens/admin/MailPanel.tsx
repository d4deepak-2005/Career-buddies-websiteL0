import React, { useCallback, useEffect, useState } from 'react';
import { Inbox, Mail, Pencil, RefreshCw, Send } from 'lucide-react';
import { adminFetch } from '../../../utils/adminAuth';
import { Skeleton } from '../../common/Skeleton';

type MailView = 'inbox' | 'sent' | 'compose';
type Audience = 'one' | 'leads' | 'users' | 'custom';

interface InboxRow {
  uid: number;
  from: string;
  to: string;
  subject: string;
  date: string;
  seen: boolean;
}

interface SentRow {
  id: string;
  to: string;
  subject: string;
  body: string;
  audience: string;
  status: string;
  error: string;
  actorName: string;
  createdAt: string;
}

function formatWhen(iso?: string) {
  if (!iso) return '';
  const date = new Date(iso);
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  if (sameDay) {
    return date.toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit' });
  }
  return date.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });
}

function formatFull(iso?: string) {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('en-IN', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  });
}

function displayName(raw: string) {
  const value = String(raw || '').trim();
  if (!value) return 'Unknown';
  const match = value.match(/^([^<]+)</);
  return (match?.[1] || value.split('@')[0] || value).replace(/"/g, '').trim() || value;
}

function initials(raw: string) {
  const name = displayName(raw);
  return name
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0] || '')
    .join('')
    .toUpperCase() || 'M';
}

export const MailPanel: React.FC = () => {
  const [view, setView] = useState<MailView>('inbox');
  const [status, setStatus] = useState({ smtp: false, imap: false, from: '', inboxUser: '', imapHost: '' });
  const [inbox, setInbox] = useState<InboxRow[]>([]);
  const [sent, setSent] = useState<SentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [openUid, setOpenUid] = useState<number | null>(null);
  const [openSent, setOpenSent] = useState<SentRow | null>(null);
  const [reading, setReading] = useState<{ subject: string; from: string; to: string; date: string; text: string } | null>(null);
  const [audience, setAudience] = useState<Audience>('one');
  const [to, setTo] = useState('');
  const [emails, setEmails] = useState('');
  const [subject, setSubject] = useState('');
  const [body, setBody] = useState('');
  const [sending, setSending] = useState(false);
  const [flash, setFlash] = useState('');

  const loadStatus = useCallback(async () => {
    const res = await adminFetch('/api/admin/mail/status');
    const data = await res.json().catch(() => ({}));
    if (data?.success) {
      setStatus({
        smtp: !!data.smtp,
        imap: !!data.imap,
        from: String(data.from || ''),
        inboxUser: String(data.inboxUser || ''),
        imapHost: String(data.imapHost || ''),
      });
    }
  }, []);

  const loadInbox = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await adminFetch('/api/admin/mail/inbox');
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        setError(data.error || 'Could not load inbox.');
        setInbox([]);
        return;
      }
      setInbox(Array.isArray(data.items) ? data.items : []);
    } catch {
      setError('Could not reach the server.');
      setInbox([]);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadSent = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const res = await adminFetch('/api/admin/mail/sent');
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        setError(data.error || 'Could not load sent mail.');
        setSent([]);
        return;
      }
      setSent(Array.isArray(data.items) ? data.items : []);
    } catch {
      setError('Could not reach the server.');
      setSent([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadStatus();
  }, [loadStatus]);

  useEffect(() => {
    setOpenUid(null);
    setOpenSent(null);
    setReading(null);
    setError('');
    setFlash('');
    if (view === 'inbox') loadInbox();
    if (view === 'sent') loadSent();
    if (view === 'compose') setLoading(false);
  }, [view, loadInbox, loadSent]);

  const openInbox = async (uid: number) => {
    setOpenUid(uid);
    setReading(null);
    try {
      const res = await adminFetch(`/api/admin/mail/inbox/${uid}`);
      const data = await res.json().catch(() => ({}));
      if (data?.item) setReading(data.item);
      else setError(data.error || 'Could not open this message.');
    } catch {
      setError('Could not open this message.');
    }
  };

  const handleSend = async () => {
    setSending(true);
    setError('');
    setFlash('');
    try {
      const res = await adminFetch(audience === 'one' ? '/api/admin/mail/send' : '/api/admin/mail/bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ audience, to, emails, subject, body }),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || !data.success) {
        setError(data.error || 'Could not send.');
        return;
      }
      setFlash(audience === 'one' ? 'Message sent.' : `Sent ${data.sent || 0} of ${data.total || 0}${data.failed ? `, ${data.failed} failed` : ''}.`);
      setSubject('');
      setBody('');
      setTo('');
      setEmails('');
    } catch {
      setError('Could not send.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="bg-[var(--admin-sidebar)] rounded-2xl border border-[var(--admin-border)] overflow-hidden min-h-[640px] flex">
      <aside className="hidden md:flex w-[200px] shrink-0 flex-col border-r border-[var(--admin-border)] py-4">
        <div className="px-3 mb-4">
          <button
            type="button"
            onClick={() => setView('compose')}
            className="w-full h-10 rounded-full bg-[var(--admin-accent)] text-white text-[13px] font-medium cursor-pointer inline-flex items-center justify-center gap-2 hover:brightness-105"
          >
            <Pencil className="w-4 h-4" />
            Compose
          </button>
        </div>
        {[
          { id: 'inbox' as const, label: 'Inbox', icon: Inbox, count: inbox.length },
          { id: 'sent' as const, label: 'Sent', icon: Mail, count: sent.length },
        ].map((item) => {
          const Icon = item.icon;
          const on = view === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => setView(item.id)}
              className={`mx-2 h-9 px-3 rounded-r-full text-[13px] cursor-pointer flex items-center gap-2.5 ${
                on ? 'bg-[var(--admin-soft)] text-[var(--admin-text)] font-semibold' : 'text-[var(--admin-text)] hover:bg-[var(--admin-hover)]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="flex-1 text-left">{item.label}</span>
              {view !== 'compose' && item.count > 0 && (
                <span className="text-[11px] text-[var(--admin-muted)]">{item.count}</span>
              )}
            </button>
          );
        })}
        <p className="mt-auto px-4 pt-4 text-[11px] text-[var(--admin-muted)] leading-relaxed">
          {status.inboxUser || status.from || 'Mailbox'}
        </p>
      </aside>

      <div className="flex-1 min-w-0 flex flex-col">
        <div className="h-12 px-4 border-b border-[var(--admin-border)] flex items-center justify-between gap-3">
          <div className="md:hidden flex items-center gap-1">
            {(['inbox', 'sent', 'compose'] as MailView[]).map((id) => (
              <button
                key={id}
                type="button"
                onClick={() => setView(id)}
                className={`h-8 px-3 rounded-full text-[12px] cursor-pointer ${
                  view === id ? 'bg-[var(--admin-soft)] font-semibold' : 'hover:bg-[var(--admin-hover)]'
                }`}
              >
                {id === 'inbox' ? 'Inbox' : id === 'sent' ? 'Sent' : 'Compose'}
              </button>
            ))}
          </div>
          <p className="hidden md:block text-[14px] font-medium text-[var(--admin-text)]">
            {view === 'inbox' ? 'Inbox' : view === 'sent' ? 'Sent' : 'New message'}
          </p>
          {view !== 'compose' && (
            <button
              type="button"
              onClick={() => (view === 'inbox' ? loadInbox() : loadSent())}
              className="w-8 h-8 rounded-full text-[var(--admin-muted)] hover:bg-[var(--admin-hover)] hover:text-[var(--admin-text)] cursor-pointer flex items-center justify-center"
              aria-label="Refresh"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          )}
        </div>

        {error && <p className="px-4 py-2 text-[13px] text-red-700">{error}</p>}
        {flash && <p className="px-4 py-2 text-[13px] text-[#0b6b2b]">{flash}</p>}

        {view === 'compose' && (
          <div className="flex-1 flex flex-col min-h-0">
            <div className="px-5">
              <div className="mail-row">
                <span className="text-[13px] text-[var(--admin-muted)] w-10 shrink-0">To</span>
                {audience === 'one' ? (
                  <input className="mail-line flex-1" value={to} onChange={(e) => setTo(e.target.value)} placeholder="Recipient" />
                ) : audience === 'custom' ? (
                  <input className="mail-line flex-1" value={emails} onChange={(e) => setEmails(e.target.value)} placeholder="Emails, separated by comma" />
                ) : (
                  <span className="flex-1 text-[14px] text-[var(--admin-text)]">
                    {audience === 'leads' ? 'All leads with an email' : 'All registered users'}
                  </span>
                )}
                <select
                  value={audience}
                  onChange={(e) => setAudience(e.target.value as Audience)}
                  className="mail-line w-[140px] shrink-0"
                  aria-label="Audience"
                >
                  <option value="one">One person</option>
                  <option value="leads">All leads</option>
                  <option value="users">All users</option>
                  <option value="custom">List</option>
                </select>
              </div>
              <div className="mail-row">
                <span className="text-[13px] text-[var(--admin-muted)] w-10 shrink-0">From</span>
                <p className="flex-1 text-[14px] text-[var(--admin-muted)]">{status.from || 'SMTP not set'}</p>
              </div>
              <div className="mail-row">
                <span className="text-[13px] text-[var(--admin-muted)] w-10 shrink-0">Subj</span>
                <input className="mail-line flex-1" value={subject} onChange={(e) => setSubject(e.target.value)} placeholder="Subject" />
              </div>
            </div>
            <div className="flex-1 px-5 pt-3">
              <textarea
                className="mail-body w-full"
                value={body}
                onChange={(e) => setBody(e.target.value)}
                placeholder="Write your message"
              />
            </div>
            <div className="px-5 py-3 border-t border-[var(--admin-border)] flex items-center gap-3">
              <button
                type="button"
                onClick={handleSend}
                disabled={sending || !status.smtp}
                className="h-9 px-5 rounded-full bg-[var(--admin-accent)] text-white text-[13px] font-medium cursor-pointer inline-flex items-center gap-2 disabled:opacity-45"
              >
                <Send className="w-3.5 h-3.5" />
                {sending ? 'Sending…' : 'Send'}
              </button>
              {!status.smtp && <p className="text-[12px] text-[var(--admin-muted)]">SMTP is not configured.</p>}
            </div>
          </div>
        )}

        {view !== 'compose' && loading && (
          <div className="p-4 flex flex-col gap-2">
            <Skeleton className="h-10 rounded-lg" />
            <Skeleton className="h-10 rounded-lg" />
            <Skeleton className="h-10 rounded-lg" />
          </div>
        )}

        {view === 'inbox' && !loading && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-[380px_minmax(0,1fr)] min-h-0">
            <div className="border-r border-[var(--admin-border)] overflow-y-auto max-h-[70vh]">
              {inbox.length === 0 ? (
                <p className="p-10 text-center text-[13px] text-[var(--admin-muted)]">
                  {status.imap ? 'Inbox is empty.' : 'IMAP is not configured yet.'}
                </p>
              ) : (
                inbox.map((row) => {
                  const on = openUid === row.uid;
                  return (
                    <button
                      key={row.uid}
                      type="button"
                      onClick={() => openInbox(row.uid)}
                      className={`w-full px-3 py-2.5 flex items-start gap-3 text-left cursor-pointer ${
                        on ? 'bg-[var(--admin-soft)]' : 'hover:bg-[var(--admin-hover)]'
                      }`}
                    >
                      <span className="w-8 h-8 mt-0.5 rounded-full bg-[var(--admin-page)] text-[11px] font-semibold flex items-center justify-center shrink-0">
                        {initials(row.from)}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className={`truncate text-[13px] ${row.seen ? 'font-medium' : 'font-semibold'} text-[var(--admin-text)]`}>
                            {displayName(row.from)}
                          </span>
                          <span className="ml-auto text-[11px] text-[var(--admin-muted)] shrink-0">{formatWhen(row.date)}</span>
                        </span>
                        <span className="block text-[13px] text-[var(--admin-text)] truncate">{row.subject}</span>
                      </span>
                    </button>
                  );
                })
              )}
            </div>
            <div className="overflow-y-auto max-h-[70vh]">
              {!reading ? (
                <div className="h-full min-h-[280px] flex items-center justify-center text-[13px] text-[var(--admin-muted)]">
                  Select a conversation
                </div>
              ) : (
                <div className="p-6">
                  <h3 className="text-[22px] font-normal text-[var(--admin-text)] tracking-tight">{reading.subject}</h3>
                  <div className="mt-5 flex items-start gap-3">
                    <span className="w-10 h-10 rounded-full bg-[var(--admin-soft)] text-[12px] font-semibold flex items-center justify-center shrink-0">
                      {initials(reading.from)}
                    </span>
                    <div className="min-w-0">
                      <p className="text-[14px] font-medium text-[var(--admin-text)]">{displayName(reading.from)}</p>
                      <p className="text-[12px] text-[var(--admin-muted)]">{reading.from}</p>
                      <p className="text-[12px] text-[var(--admin-muted)]">to {reading.to || 'me'}</p>
                    </div>
                    <p className="ml-auto text-[12px] text-[var(--admin-muted)] shrink-0">{formatFull(reading.date)}</p>
                  </div>
                  <div className="mt-6 text-[14px] leading-7 text-[var(--admin-text)] whitespace-pre-wrap break-words">
                    {reading.text}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {view === 'sent' && !loading && (
          <div className="flex-1 grid grid-cols-1 lg:grid-cols-[380px_minmax(0,1fr)] min-h-0">
            <div className="border-r border-[var(--admin-border)] overflow-y-auto max-h-[70vh]">
              {sent.length === 0 ? (
                <p className="p-10 text-center text-[13px] text-[var(--admin-muted)]">No sent mail yet.</p>
              ) : (
                sent.map((row) => {
                  const on = openSent?.id === row.id;
                  return (
                    <button
                      key={row.id}
                      type="button"
                      onClick={() => setOpenSent(row)}
                      className={`w-full px-3 py-2.5 flex items-start gap-3 text-left cursor-pointer ${
                        on ? 'bg-[var(--admin-soft)]' : 'hover:bg-[var(--admin-hover)]'
                      }`}
                    >
                      <span className="w-8 h-8 mt-0.5 rounded-full bg-[var(--admin-page)] text-[11px] font-semibold flex items-center justify-center shrink-0">
                        {initials(row.to)}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2">
                          <span className="truncate text-[13px] font-medium text-[var(--admin-text)]">To {displayName(row.to)}</span>
                          <span className="ml-auto text-[11px] text-[var(--admin-muted)] shrink-0">{formatWhen(row.createdAt)}</span>
                        </span>
                        <span className="block text-[13px] text-[var(--admin-text)] truncate">{row.subject}</span>
                      </span>
                    </button>
                  );
                })
              )}
            </div>
            <div className="overflow-y-auto max-h-[70vh]">
              {!openSent ? (
                <div className="h-full min-h-[280px] flex items-center justify-center text-[13px] text-[var(--admin-muted)]">
                  Select a sent message
                </div>
              ) : (
                <div className="p-6">
                  <h3 className="text-[22px] font-normal text-[var(--admin-text)] tracking-tight">{openSent.subject}</h3>
                  <div className="mt-5 flex items-start gap-3">
                    <span className="w-10 h-10 rounded-full bg-[var(--admin-soft)] text-[12px] font-semibold flex items-center justify-center shrink-0">
                      {initials(openSent.to)}
                    </span>
                    <div className="min-w-0">
                      <p className="text-[14px] font-medium text-[var(--admin-text)]">To {openSent.to}</p>
                      <p className="text-[12px] text-[var(--admin-muted)]">{formatFull(openSent.createdAt)}</p>
                    </div>
                  </div>
                  <div className="mt-6 text-[14px] leading-7 text-[var(--admin-text)] whitespace-pre-wrap break-words">
                    {openSent.body}
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
