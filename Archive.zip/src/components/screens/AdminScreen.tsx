import React, { useState, useEffect } from 'react';
import { Lead } from '../../types';
import { 
  Users, 
  FileText, 
  Settings, 
  Download, 
  PhoneCall, 
  Search, 
  Inbox,
  CreditCard,
  UserCircle2,
  KeyRound,
  LayoutDashboard,
  Video,
  FolderOpen,
  Menu,
  X,
  ExternalLink,
  LogOut,
  Bell,
  PanelLeftClose,
  PanelLeftOpen,
  ScrollText,
  BarChart3,
  Code2,
  Sun,
  Moon,
  RefreshCw,
  ChevronsUpDown,
  Mail
} from 'lucide-react';
import { PaymentsPanel } from './admin/PaymentsPanel';
import { UsersPanel } from './admin/UsersPanel';
import { AdminTeamPanel } from './admin/AdminTeamPanel';
import { adminFetch, clearAdminToken, getAdminProfile, getAdminTheme, getSidebarCollapsed, setAdminProfile, setAdminTheme, setSidebarCollapsed, type AdminTheme } from '../../utils/adminAuth';
import { useSiteSettings } from '../../hooks/useSiteSettings';
import { SiteSettingsPanel } from './admin/SiteSettingsPanel';
import { PeopleMentorsPanel } from './admin/PeopleMentorsPanel';
import { CandidateContentPanel } from './admin/CandidateContentPanel';
import { CatalogPanel, WEBINAR_FIELDS } from './admin/CatalogPanel';
import { RecordListEditor } from './admin/RecordListEditor';
import { downloadExcel, inDateRange, stampFileDate } from '../../utils/excelExport';
import { ExportExcelDialog, DateRange } from './admin/ExportExcelDialog';
import { useAdminNotifications } from '../../hooks/useAdminNotifications';
import { NotificationsDrawer } from './admin/NotificationsDrawer';
import { NotificationsPanel } from './admin/NotificationsPanel';
import { LogsPanel } from './admin/LogsPanel';
import { SeoPanel } from './admin/SeoPanel';
import { HomeHtmlPanel } from './admin/HomeHtmlPanel';
import { MailPanel } from './admin/MailPanel';

interface AdminScreenProps {
  onOpenLeadDetail?: (lead: Lead) => void;
  setActivePage?: (page: any) => void;
}

const ADMIN_TABS = [
  'overview',
  'leads',
  'payments',
  'users',
  'team',
  'webinars',
  'catalog',
  'people',
  'candidates',
  'settings',
  'html',
  'seo',
  'notifications',
  'logs',
  'mail',
] as const;

type AdminTab = (typeof ADMIN_TABS)[number];
const TAB_KEY = 'cb_admin_tab';

function isAdminTab(value: string): value is AdminTab {
  return (ADMIN_TABS as readonly string[]).includes(value);
}

function readAdminTab(): AdminTab {
  const hash = window.location.hash;
  const fromHash = hash.startsWith('#admin/') ? hash.slice('#admin/'.length) : '';
  if (fromHash && isAdminTab(fromHash)) return fromHash;
  try {
    const stored = localStorage.getItem(TAB_KEY) || '';
    if (stored && isAdminTab(stored)) return stored;
  } catch {
    /* ignore */
  }
  return 'overview';
}

type AdminWebinarRow = {
  id: string;
  title: string;
  speakerName: string;
  date: string;
  priceINR: number;
  status: string;
};

function persistAdminTab(tab: AdminTab) {
  try {
    localStorage.setItem(TAB_KEY, tab);
  } catch {
    /* ignore */
  }
  if (!window.location.hash.startsWith('#admin')) return;
  const next = tab === 'overview' ? '#admin' : `#admin/${tab}`;
  if (window.location.hash !== next) {
    window.history.replaceState(window.history.state, '', next);
  }
}

export const AdminScreen: React.FC<AdminScreenProps> = ({ setActivePage }) => {
  const { settings: liveSettings } = useSiteSettings();
  const maintenanceOn = !!liveSettings?.maintenance?.enabled;
  const [activeTab, setActiveTab] = useState<AdminTab>(readAdminTab);
  const [leads, setLeads] = useState<Lead[]>([]);
  const [webinars, setWebinars] = useState<AdminWebinarRow[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchLead, setSearchLead] = useState('');
  const [leadStatusFilter, setLeadStatusFilter] = useState('all');
  const [exportOpen, setExportOpen] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsedState] = useState(getSidebarCollapsed);
  const [theme, setThemeState] = useState<AdminTheme>(getAdminTheme);
  const [adminProfile, setAdminProfileState] = useState(getAdminProfile);
  const [notifOpen, setNotifOpen] = useState(false);
  const [accountOpen, setAccountOpen] = useState(false);
  const notices = useAdminNotifications();
  const unreadIds = new Set(notices.unread.map((n) => n.id));

  const goTab = (tab: AdminTab) => {
    setActiveTab(tab);
    persistAdminTab(tab);
    setSidebarOpen(false);
  };

  useEffect(() => {
    persistAdminTab(activeTab);
    if (activeTab === 'overview') fetchWebinars();
  }, [activeTab]);

  useEffect(() => {
    if (!accountOpen) return;
    const close = (event: MouseEvent) => {
      const target = event.target as HTMLElement | null;
      if (target?.closest('[data-admin-account]')) return;
      setAccountOpen(false);
    };
    document.addEventListener('mousedown', close);
    return () => document.removeEventListener('mousedown', close);
  }, [accountOpen]);

  const toggleSidebarCollapsed = () => {
    const next = !sidebarCollapsed;
    setSidebarCollapsedState(next);
    setSidebarCollapsed(next);
  };

  const applyTheme = (next: AdminTheme) => {
    setThemeState(next);
    setAdminTheme(next);
  };

  useEffect(() => {
    fetchLeads();
    fetchWebinars();
    adminFetch('/api/admin/me')
      .then((res) => res.json())
      .then((data) => {
        if (!data?.success || !data.name) return;
        const current = getAdminProfile();
        if (data.name === 'Owner' && current.name && current.name !== 'Owner') return;
        const profile = { name: String(data.name), source: data.source === 'team' ? 'team' as const : 'owner' as const };
        setAdminProfile(profile);
        setAdminProfileState(profile);
      })
      .catch(() => undefined);
  }, []);

  const fetchWebinars = async () => {
    try {
      const res = await adminFetch('/api/webinars/admin');
      const data = await res.json();
      if (!data?.success) return;
      setWebinars(
        (data.items || []).map((w: any) => ({
          id: String(w._id || w.id || ''),
          title: String(w.title || 'Untitled webinar'),
          speakerName: String(w.speakerName || ''),
          date: String(w.date || ''),
          priceINR: Number(w.priceINR) || 0,
          status: String(w.status || 'upcoming'),
        }))
      );
    } catch (err) {
      console.warn('Could not fetch webinars:', err);
      setWebinars([]);
    }
  };

  const fetchLeads = async () => {
    setIsLoading(true);
    try {
      const res = await adminFetch('/api/leads');
      if (res.ok) {
        const data = await res.json();
        if (data.leads) setLeads(data.leads);
      }
    } catch (err) {
      console.warn('Could not fetch from server, using existing state:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleUpdateLeadStatus = async (leadId: string, status: 'new' | 'contacted' | 'scheduled' | 'converted') => {
    try {
      await adminFetch(`/api/leads/${leadId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status })
      });
      setLeads(prev => prev.map(l => l.id === leadId ? { ...l, status } : l));
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  type NavItem = { id: AdminTab; label: string; icon: React.ComponentType<{ className?: string }>; badge?: number };
  const navGroups: { title: string; items: NavItem[] }[] = [
    {
      title: 'Workspace',
      items: [
        { id: 'overview', label: 'Overview', icon: LayoutDashboard },
        { id: 'notifications', label: 'Notifications', icon: Bell, badge: notices.unreadCount || undefined },
        { id: 'logs', label: 'Logs', icon: ScrollText },
      ],
    },
    {
      title: 'Operations',
      items: [
        { id: 'leads', label: 'Leads', icon: Inbox, badge: leads.length },
        { id: 'payments', label: 'Payments', icon: CreditCard },
        { id: 'users', label: 'Users', icon: UserCircle2 },
        { id: 'team', label: 'Team', icon: KeyRound },
        { id: 'mail', label: 'Mail', icon: Mail },
      ],
    },
    {
      title: 'Content',
      items: [
        { id: 'webinars', label: 'Webinars', icon: Video, badge: webinars.length || undefined },
        { id: 'catalog', label: 'Catalog', icon: FileText },
        { id: 'people', label: 'People', icon: Users },
        { id: 'candidates', label: 'Candidates', icon: FolderOpen },
      ],
    },
    {
      title: 'Site',
      items: [
        { id: 'settings', label: 'Settings', icon: Settings },
        { id: 'html', label: 'Home HTML', icon: Code2 },
        { id: 'seo', label: 'SEO & Traffic', icon: BarChart3 },
      ],
    },
  ];
  const navItems = navGroups.flatMap((group) => group.items);

  const currentNav = navItems.find((item) => item.id === activeTab);

  const filteredLeads = leads.filter(l => {
    const matchStatus = leadStatusFilter === 'all' || l.status === leadStatusFilter;
    const q = searchLead.toLowerCase();
    const matchQ = !q ||
      l.fullName.toLowerCase().includes(q) ||
      l.email.toLowerCase().includes(q) ||
      l.mobile.includes(q) ||
      (l.requirement && l.requirement.toLowerCase().includes(q));
    return matchStatus && matchQ;
  });

  const leadsForExport = (range: DateRange) =>
    filteredLeads.filter((l) => inDateRange(l.createdAt, range.from, range.to));

  const exportLeadsExcel = (range: DateRange) => {
    const rows = leadsForExport(range);
    if (rows.length === 0) return;
    downloadExcel(
      `careerbuddies-leads-${stampFileDate()}`,
      'Leads',
      ['S.No', 'Date (IST)', 'Name', 'Mobile', 'Email', 'Role', 'Experience', 'Industry', 'Requirement', 'Plan interest', 'Status', 'Source'],
      rows.map((l) => [
        l.serialNumber,
        l.timestampIST || '',
        l.fullName,
        l.mobile,
        l.email,
        l.currentRole || '',
        l.experience || '',
        l.industry || '',
        l.requirement || '',
        l.planInterest || '',
        l.status,
        l.source,
      ])
    );
    setExportOpen(false);
  };

  const adminName = adminProfile.name || 'Owner';
  const adminInitials = adminName
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((part) => part[0] || '')
    .join('')
    .toUpperCase() || 'AD';

  const renderSidebar = (collapsed: boolean, allowCollapse: boolean) => (
    <aside
      className={`h-full bg-[var(--admin-sidebar)] text-[var(--admin-text)] flex flex-col shrink-0 border-r border-[var(--admin-border)] transition-[width] duration-200 ${
        collapsed ? 'w-[72px]' : 'w-[248px]'
      }`}
    >
      <div className={`border-b border-[var(--admin-border)] ${collapsed ? 'px-2 py-4' : 'px-4 py-4'}`}>
        <div className={`flex items-center ${collapsed ? 'flex-col gap-3' : 'gap-2.5'}`}>
          <div className="w-8 h-8 rounded-lg bg-[var(--admin-soft)] text-[var(--admin-text)] text-[11px] font-semibold tracking-wide flex items-center justify-center shrink-0">
            CB
          </div>
          {!collapsed && (
            <div className="min-w-0 flex-1">
              <p className="text-[13px] font-semibold text-[var(--admin-text)] leading-tight tracking-tight">Console</p>
              <p className="text-[11px] text-[var(--admin-muted)]">Workspace</p>
            </div>
          )}
          {allowCollapse && (
            <button
              type="button"
              onClick={toggleSidebarCollapsed}
              className="p-1.5 rounded-md text-[var(--admin-muted)] hover:bg-[var(--admin-hover)] hover:text-[var(--admin-text)] cursor-pointer"
              aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
              title={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
            >
              {collapsed ? <PanelLeftOpen className="w-4 h-4" /> : <PanelLeftClose className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>
      <nav className={`flex-1 overflow-y-auto ${collapsed ? 'px-2 py-3' : 'px-3 py-3'}`}>
        {navGroups.map((group) => (
          <div key={group.title} className={collapsed ? 'mb-3' : 'mb-4'}>
            {!collapsed && (
              <p className="px-2.5 mb-1.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-[var(--admin-muted)]">
                {group.title}
              </p>
            )}
            <div className="flex flex-col gap-0.5">
              {group.items.map((item) => {
                const Icon = item.icon;
                const on = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => goTab(item.id)}
                    title={collapsed ? item.label : undefined}
                    aria-label={item.label}
                    className={`relative w-full flex items-center rounded-md text-[13px] cursor-pointer ${
                      collapsed ? 'justify-center h-9' : 'gap-2.5 px-2.5 h-9 text-left'
                    } ${
                      on
                        ? 'bg-[var(--admin-active)] text-[var(--admin-text)]'
                        : 'text-[var(--admin-muted)] hover:bg-[var(--admin-hover)] hover:text-[var(--admin-text)]'
                    }`}
                  >
                    {on && !collapsed && (
                      <span className="absolute left-0 top-1.5 bottom-1.5 w-[2px] rounded-full bg-[var(--admin-accent)]" />
                    )}
                    <span className="relative">
                      <Icon className={`w-[16px] h-[16px] shrink-0 ${on ? 'text-[var(--admin-accent)]' : 'text-[var(--admin-muted)]'}`} />
                      {collapsed && typeof item.badge === 'number' && item.badge > 0 && (
                        <span className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] px-0.5 rounded-full bg-[var(--admin-accent)] text-white text-[8px] font-semibold flex items-center justify-center">
                          {item.badge > 9 ? '9+' : item.badge}
                        </span>
                      )}
                    </span>
                    {!collapsed && <span className="flex-1 font-medium">{item.label}</span>}
                    {!collapsed && typeof item.badge === 'number' && (
                      <span className={`min-w-[20px] px-1.5 py-0.5 rounded text-[10px] font-medium text-center ${
                        on ? 'bg-[var(--admin-soft)] text-[var(--admin-accent)]' : 'bg-[var(--admin-soft)] text-[var(--admin-muted)]'
                      }`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </nav>
      <div data-admin-account className={`relative border-t border-[var(--admin-border)] ${collapsed ? 'px-2 py-3' : 'px-3 py-3'}`}>
        {accountOpen && (
          <div className={`absolute z-30 rounded-xl border border-[var(--admin-border)] bg-[var(--admin-sidebar)] shadow-[0_12px_40px_rgba(0,0,0,0.12)] py-1.5 ${
            collapsed ? 'left-full bottom-3 ml-2 w-48' : 'left-3 right-3 bottom-full mb-2'
          }`}>
            {setActivePage && (
              <button
                type="button"
                onClick={() => {
                  setAccountOpen(false);
                  setActivePage('home');
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="w-full flex items-center gap-2.5 px-3 h-9 text-[13px] text-[var(--admin-text)] hover:bg-[var(--admin-hover)] cursor-pointer"
              >
                <ExternalLink className="w-3.5 h-3.5 text-[var(--admin-muted)]" />
                View website
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                clearAdminToken();
                window.location.reload();
              }}
              className="w-full flex items-center gap-2.5 px-3 h-9 text-[13px] text-[var(--admin-text)] hover:bg-[var(--admin-hover)] cursor-pointer"
            >
              <LogOut className="w-3.5 h-3.5 text-[var(--admin-muted)]" />
              Sign out
            </button>
          </div>
        )}
        <button
          type="button"
          onClick={() => setAccountOpen((open) => !open)}
          aria-expanded={accountOpen}
          aria-haspopup="menu"
          title={adminName}
          className={`w-full flex items-center rounded-xl bg-[var(--admin-soft)] hover:bg-[var(--admin-hover)] cursor-pointer ${
            collapsed ? 'justify-center h-10' : 'gap-2.5 px-2.5 h-12'
          }`}
        >
          <div className="w-8 h-8 rounded-full bg-[var(--admin-page)] text-[var(--admin-text)] text-[11px] font-semibold flex items-center justify-center shrink-0">
            {adminInitials}
          </div>
          {!collapsed && (
            <>
              <div className="min-w-0 flex-1 text-left">
                <p className="text-[13px] font-medium text-[var(--admin-text)] truncate">{adminName}</p>
                <p className="text-[11px] text-[var(--admin-muted)]">Administrator</p>
              </div>
              <ChevronsUpDown className="w-3.5 h-3.5 text-[var(--admin-muted)] shrink-0" />
            </>
          )}
        </button>
      </div>
    </aside>
  );

  return (
    <div className={`admin-console admin-theme-${theme} w-full min-h-screen flex`}>
      <div className="hidden lg:block sticky top-0 h-screen">{renderSidebar(sidebarCollapsed, true)}</div>

      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <button type="button" className="absolute inset-0 bg-black/40" aria-label="Close menu" onClick={() => setSidebarOpen(false)} />
          <div className="relative z-10 h-full">{renderSidebar(false, false)}</div>
        </div>
      )}

      <div className="flex-1 min-w-0 flex flex-col">
        <header className="sticky top-0 z-20 bg-[var(--admin-header)] backdrop-blur border-b border-[var(--admin-border)] px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              className="lg:hidden p-2 rounded-lg border border-[var(--admin-border)] text-[var(--admin-text)] cursor-pointer"
              onClick={() => setSidebarOpen(true)}
              aria-label="Open admin menu"
            >
              {sidebarOpen ? <X className="w-4 h-4" /> : <Menu className="w-4 h-4" />}
            </button>
            <div className="min-w-0">
              <h1 className="text-[15px] font-semibold text-[var(--admin-text)] truncate">{currentNav?.label || 'Console'}</h1>
              <p className="text-[11px] text-[var(--admin-muted)] hidden sm:block">Internal workspace</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center rounded-lg border border-[var(--admin-border)] p-0.5 bg-[var(--admin-soft)]" role="group" aria-label="Admin theme">
              <button
                type="button"
                aria-pressed={theme === 'light'}
                onClick={() => applyTheme('light')}
                className={`p-1.5 rounded-md cursor-pointer ${
                  theme === 'light' ? 'bg-[var(--admin-page)] text-[var(--admin-text)] shadow-sm' : 'text-[var(--admin-muted)]'
                }`}
                title="Light theme"
                aria-label="Light theme"
              >
                <Sun className="w-3.5 h-3.5" />
              </button>
              <button
                type="button"
                aria-pressed={theme === 'dark'}
                onClick={() => applyTheme('dark')}
                className={`p-1.5 rounded-md cursor-pointer ${
                  theme === 'dark' ? 'bg-[var(--admin-page)] text-[var(--admin-text)] shadow-sm' : 'text-[var(--admin-muted)]'
                }`}
                title="Dark theme"
                aria-label="Dark theme"
              >
                <Moon className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="hidden sm:flex items-center gap-2 px-2 py-1 rounded-lg bg-[var(--admin-soft)] min-w-0">
              <div className="w-6 h-6 rounded-full bg-[var(--admin-page)] text-[var(--admin-text)] text-[10px] font-semibold flex items-center justify-center shrink-0">
                {adminInitials}
              </div>
              <p className="text-[13px] font-medium text-[var(--admin-text)] truncate max-w-[140px]">{adminName}</p>
            </div>
            <button
              type="button"
              onClick={() => setNotifOpen(true)}
              className="relative p-2 rounded-lg border border-[var(--admin-border)] text-[var(--admin-text)] hover:bg-[var(--admin-hover)] cursor-pointer"
              aria-label="Open notifications"
            >
              <Bell className="w-4 h-4" />
              {notices.unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 min-w-[16px] h-[16px] px-1 rounded-full bg-[#5b8def] text-white text-[9px] font-semibold flex items-center justify-center">
                  {notices.unreadCount > 99 ? '99+' : notices.unreadCount}
                </span>
              )}
            </button>
          {maintenanceOn && (
            <button
              type="button"
              onClick={() => goTab('settings')}
              className="text-[11px] font-bold text-amber-800 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg cursor-pointer"
            >
              Maintenance on
            </button>
          )}
          </div>
        </header>

        <div className="flex-1 p-4 sm:p-6 flex flex-col gap-6">
        {maintenanceOn && (
          <div className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <p className="text-xs font-bold text-amber-900">
              Public website is in maintenance. Visitors see the offline page until you turn this off.
            </p>
            <button
              type="button"
              onClick={() => goTab('settings')}
              className="text-xs font-bold text-amber-900 underline cursor-pointer shrink-0"
            >
              Open Site Settings
            </button>
          </div>
        )}

        {/* TAB 1: OVERVIEW */}
        {activeTab === 'overview' && (
          <div className="flex flex-col gap-5">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { label: 'Leads', value: leads.length, hint: 'All enquiries', icon: Inbox, tab: 'leads' as AdminTab },
                { label: 'Scheduled', value: leads.filter((l) => l.status === 'scheduled').length, hint: 'Ready to meet', icon: PhoneCall, tab: 'leads' as AdminTab },
                { label: 'Webinars', value: webinars.length, hint: `${webinars.filter((w) => w.status !== 'completed').length} live`, icon: Video, tab: 'webinars' as AdminTab },
              ].map((card) => {
                const Icon = card.icon;
                return (
                  <button
                    key={card.label}
                    type="button"
                    onClick={() => goTab(card.tab)}
                    className="text-left bg-[var(--admin-sidebar)] rounded-2xl border border-[var(--admin-border)] p-5 cursor-pointer hover:bg-[var(--admin-hover)]"
                  >
                    <div className="flex items-center justify-between">
                      <p className="text-[11px] uppercase tracking-[0.14em] text-[var(--admin-muted)]">{card.label}</p>
                      <span className="w-8 h-8 rounded-lg bg-[var(--admin-soft)] text-[var(--admin-muted)] flex items-center justify-center">
                        <Icon className="w-4 h-4" />
                      </span>
                    </div>
                    <p className="mt-4 text-[28px] leading-none font-semibold tracking-tight text-[var(--admin-text)]">{card.value}</p>
                    <p className="mt-2 text-[12px] text-[var(--admin-muted)]">{card.hint}</p>
                  </button>
                );
              })}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div className="bg-[var(--admin-sidebar)] rounded-2xl border border-[var(--admin-border)] overflow-hidden">
                <div className="px-5 h-12 flex items-center justify-between border-b border-[var(--admin-border)]">
                  <h2 className="text-[13px] font-semibold text-[var(--admin-text)]">Recent inquiries</h2>
                  <button type="button" onClick={() => goTab('leads')} className="text-[12px] text-[var(--admin-muted)] hover:text-[var(--admin-text)] cursor-pointer">
                    View all
                  </button>
                </div>
                {leads.length === 0 ? (
                  <p className="px-5 py-10 text-[13px] text-[var(--admin-muted)] text-center">No inquiries yet.</p>
                ) : (
                  <div>
                    {leads.slice(0, 5).map((l) => (
                      <button
                        key={l.id}
                        type="button"
                        onClick={() => goTab('leads')}
                        className="w-full px-5 py-3 flex items-center gap-3 text-left hover:bg-[var(--admin-hover)] cursor-pointer border-b border-[var(--admin-border)] last:border-b-0"
                      >
                        <span className="w-8 h-8 rounded-full bg-[var(--admin-soft)] text-[11px] font-semibold text-[var(--admin-text)] flex items-center justify-center shrink-0">
                          {(l.fullName || 'L').trim().split(/\s+/).slice(0, 2).map((p) => p[0] || '').join('').toUpperCase() || 'L'}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block text-[13px] font-medium text-[var(--admin-text)] truncate">{l.fullName}</span>
                          <span className="block text-[12px] text-[var(--admin-muted)] truncate">{[l.email, l.mobile].filter(Boolean).join(' · ')}</span>
                        </span>
                        <span className={`shrink-0 px-2 py-0.5 rounded-md text-[11px] font-medium capitalize ${
                          l.status === 'scheduled' ? 'admin-tone-ok' : 'admin-tone-info'
                        }`}>
                          {l.status}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="bg-[var(--admin-sidebar)] rounded-2xl border border-[var(--admin-border)] overflow-hidden">
                <div className="px-5 h-12 flex items-center justify-between border-b border-[var(--admin-border)]">
                  <h2 className="text-[13px] font-semibold text-[var(--admin-text)]">Webinars</h2>
                  <button type="button" onClick={() => goTab('webinars')} className="text-[12px] text-[var(--admin-muted)] hover:text-[var(--admin-text)] cursor-pointer">
                    Manage
                  </button>
                </div>
                {webinars.length === 0 ? (
                  <p className="px-5 py-10 text-[13px] text-[var(--admin-muted)] text-center">No webinars in the CMS yet.</p>
                ) : (
                  <div>
                    {webinars.slice(0, 5).map((w) => (
                      <button
                        key={w.id}
                        type="button"
                        onClick={() => goTab('webinars')}
                        className="w-full px-5 py-3 flex items-center gap-3 text-left hover:bg-[var(--admin-hover)] cursor-pointer border-b border-[var(--admin-border)] last:border-b-0"
                      >
                        <span className="min-w-0 flex-1">
                          <span className="block text-[13px] font-medium text-[var(--admin-text)] truncate">{w.title}</span>
                          <span className="block text-[12px] text-[var(--admin-muted)] truncate">
                            {[w.speakerName, w.date, w.status].filter(Boolean).join(' · ')}
                          </span>
                        </span>
                        <span className="shrink-0 text-[13px] text-[var(--admin-text)]">
                          {w.priceINR > 0 ? `₹${w.priceINR}` : '—'}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LEADS DESK */}
        {activeTab === 'leads' && (
          <div className="bg-white rounded-2xl border border-[var(--admin-border)] flex flex-col overflow-hidden">
            <div className="px-5 py-4 flex flex-col sm:flex-row gap-3 justify-between items-center border-b border-[var(--admin-border)]">
              <div className="relative w-full sm:w-80">
                <Search className="w-4 h-4 text-[var(--admin-muted)] absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input aria-label="Search leads"
                  type="text"
                  placeholder="Search by name, email, or phone..."
                  value={searchLead}
                  onChange={(e) => setSearchLead(e.target.value)}
                  className="w-full pl-10 pr-4"
                />
              </div>

              <div className="flex items-center gap-2 w-full sm:w-auto">
                <select aria-label="Filter leads by status"
                  value={leadStatusFilter}
                  onChange={(e) => setLeadStatusFilter(e.target.value)}
                  className="flex-1 sm:flex-none px-3"
                >
                  <option value="all">All statuses</option>
                  <option value="new">New</option>
                  <option value="contacted">Contacted</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="converted">Converted</option>
                </select>

                <button
                  type="button"
                  onClick={() => setExportOpen(true)}
                  disabled={filteredLeads.length === 0}
                  className="admin-btn"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export Excel
                </button>
                <button
                  type="button"
                  onClick={fetchLeads}
                  className="admin-btn"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  Refresh
                </button>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr>
                    <th>S.No</th>
                    <th>Lead name & contact</th>
                    <th>Role & experience</th>
                    <th>Requirement</th>
                    <th>Status</th>
                    <th>Time (IST)</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredLeads.map((lead) => (
                    <tr key={lead.id}>
                      <td className="text-[var(--admin-muted)]">#{lead.serialNumber}</td>
                      <td>
                        <strong className="text-[var(--admin-text)] block">{lead.fullName}</strong>
                        <span className="text-[var(--admin-muted)] text-[12px] block">{lead.email}</span>
                        <span className="text-[var(--admin-muted)] text-[12px] font-mono">{lead.mobile}</span>
                      </td>
                      <td>
                        <span className="text-[var(--admin-text)] block">{lead.currentRole || 'N/A'}</span>
                        <span className="text-[var(--admin-muted)] text-[12px]">{lead.experience || 'N/A'}</span>
                      </td>
                      <td className="max-w-xs">
                        <p className="text-[var(--admin-text)] line-clamp-2">{lead.requirement || 'Free Consultation'}</p>
                        <span className="text-[12px] text-[var(--admin-muted)]">Source: {lead.source}</span>
                      </td>
                      <td>
                        <select aria-label={`Status for ${lead.firstName} ${lead.lastName}`}
                          value={lead.status}
                          onChange={(e) => handleUpdateLeadStatus(lead.id, e.target.value as any)}
                          className="px-2.5"
                        >
                          <option value="new">New</option>
                          <option value="contacted">Contacted</option>
                          <option value="scheduled">Scheduled</option>
                          <option value="converted">Converted</option>
                        </select>
                      </td>
                      <td className="text-[12px] text-[var(--admin-muted)] whitespace-nowrap">
                        {lead.timestampIST || new Date(lead.createdAt).toLocaleDateString()}
                      </td>
                      <td>
                        <a
                          href={`https://wa.me/${lead.mobile.replace(/[^0-9]/g, '')}?text=Hi%20${encodeURIComponent(lead.firstName)}%2C%20this%20is%20CareerBuddies%20team%20following%20up%20on%20your%20career%20guidance%20request.`}
                          target="_blank"
                          rel="noreferrer"
                          className="admin-btn"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          WhatsApp
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

          </div>
        )}

        {activeTab === 'payments' && <PaymentsPanel />}

        {activeTab === 'users' && <UsersPanel />}

        {activeTab === 'team' && <AdminTeamPanel />}

        {/* TAB 3: WEBINARS MANAGEMENT (MongoDB-backed CMS) */}
        {activeTab === 'webinars' && (
          <div className="bg-[var(--admin-sidebar)] rounded-2xl border border-[var(--admin-border)] p-5 sm:p-6 flex flex-col gap-4">
            <div>
              <h2 className="text-[15px] font-semibold text-[var(--admin-text)]">Webinars</h2>
              <p className="text-[12px] text-[var(--admin-muted)] mt-1">Set the entry price on each webinar. Site buttons use the lowest live price. If none are live, those buttons stay hidden.</p>
            </div>
            <RecordListEditor
              apiBase="/api/webinars"
              labelSingular="Webinar"
              fields={WEBINAR_FIELDS}
              emptyRecord={{ title: '', status: 'upcoming', featured: false, priceINR: 0 }}
              titleField="title"
              subtitleField="date"
              imageField="speakerPhotoUrl"
            />
          </div>
        )}

        {/* TAB 3b: CATALOG (Programmes, Stories, Services, Plans — MongoDB-backed CMS) */}
        {activeTab === 'catalog' && <CatalogPanel />}

        {/* TAB 4: PEOPLE & MENTORS (MongoDB-backed CMS) */}
        {activeTab === 'people' && <PeopleMentorsPanel />}

        {/* TAB 4b: CANDIDATE CONTENT (notifications, materials, sessions, invoices) */}
        {activeTab === 'candidates' && <CandidateContentPanel />}

        {/* TAB 5: SITE SETTINGS (MongoDB-backed CMS) */}
        {activeTab === 'settings' && <SiteSettingsPanel />}

        {activeTab === 'html' && <HomeHtmlPanel />}

        {activeTab === 'seo' && <SeoPanel onOpenSettings={() => goTab('settings')} />}

        {activeTab === 'logs' && <LogsPanel />}

        {activeTab === 'mail' && <MailPanel />}

        {activeTab === 'notifications' && (
          <NotificationsPanel
            items={notices.items}
            unreadIds={unreadIds}
            onOpenItem={(item) => {
              notices.markAllRead();
              goTab(item.tab);
            }}
          />
        )}

        </div>

        <NotificationsDrawer
          isOpen={notifOpen}
          items={notices.items}
          unreadIds={unreadIds}
          onClose={() => setNotifOpen(false)}
          onOpenItem={(item) => {
            setNotifOpen(false);
            notices.markAllRead();
            goTab(item.tab);
          }}
          onViewAll={() => {
            setNotifOpen(false);
            notices.markAllRead();
            goTab('notifications');
          }}
          onMarkAllRead={notices.markAllRead}
        />

        <ExportExcelDialog
          isOpen={exportOpen}
          title="Export leads"
          description="Only Leads tab rows. Choose a date range, then download an Excel file."
          matchCount={(range) => leadsForExport(range).length}
          onClose={() => setExportOpen(false)}
          onExport={exportLeadsExcel}
        />
      </div>
    </div>
  );
};
