import { Request, Response } from 'express';
import { Lead } from '../models/Lead.ts';
import { Candidate } from '../models/Candidate.ts';
import { OutboundMail } from '../models/OutboundMail.ts';
import { isEmailConfigured, sendMail } from '../services/mailer.ts';
import { listInbox, mailboxStatus, readInboxMessage } from '../services/mailbox.ts';
import { actorFromReq, recordAdminAudit } from '../services/adminAudit.ts';
import { getPublicBaseUrl } from '../config/baseUrl.ts';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const MAX_BULK = 80;

function esc(value: string) {
  return value.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
}

function composeBodies(subject: string, body: string) {
  const text = body.trim();
  const html = `<!doctype html><html><body style="margin:0;padding:24px;background:#f1f3ff;font-family:Arial,Helvetica,sans-serif;color:#061b3b">
<table role="presentation" width="100%" cellspacing="0" cellpadding="0"><tr><td align="center">
<table role="presentation" width="560" cellspacing="0" cellpadding="0" style="max-width:560px;background:#ffffff;border-radius:16px;overflow:hidden;border:1px solid #cbdaff">
<tr><td style="background:#002869;padding:20px 28px;color:#ffffff;font-size:20px;font-weight:bold">CareerBuddies</td></tr>
<tr><td style="padding:28px"><h2 style="margin:0 0 14px;font-size:20px;color:#061b3b">${esc(subject)}</h2>
<p style="line-height:1.6;margin:0;white-space:pre-wrap">${esc(text)}</p></td></tr>
<tr><td style="padding:16px 28px;background:#f9f9ff;color:#747783;font-size:12px">${esc((getPublicBaseUrl() || '').replace(/^https?:\/\//, '') || 'careerbuddies.in')}</td></tr>
</table></td></tr></table></body></html>`;
  return { html, text };
}

function parseEmails(raw: string) {
  const unique = new Set<string>();
  String(raw || '')
    .split(/[\s,;]+/)
    .map((value) => value.trim().toLowerCase())
    .filter((value) => EMAIL_RE.test(value))
    .forEach((value) => unique.add(value));
  return [...unique].slice(0, MAX_BULK);
}

export function getMailStatus(_req: Request, res: Response) {
  res.json({ success: true, ...mailboxStatus() });
}

export async function listMailInbox(req: Request, res: Response) {
  try {
    const items = await listInbox(40);
    res.json({ success: true, items });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not load inbox.';
    res.status(502).json({ success: false, error: message });
  }
}

export async function getMailInboxMessage(req: Request, res: Response) {
  const uid = Number(req.params.uid);
  if (!Number.isFinite(uid) || uid <= 0) {
    res.status(400).json({ success: false, error: 'Invalid message.' });
    return;
  }
  try {
    const item = await readInboxMessage(uid);
    if (!item) {
      res.status(404).json({ success: false, error: 'Message not found.' });
      return;
    }
    res.json({ success: true, item });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not open message.';
    res.status(502).json({ success: false, error: message });
  }
}

export async function listSentMail(_req: Request, res: Response) {
  const items = await OutboundMail.find().sort({ createdAt: -1 }).limit(80).lean();
  res.json({
    success: true,
    items: items.map((row) => ({
      id: String(row._id),
      to: row.to,
      subject: row.subject,
      body: row.body,
      audience: row.audience,
      status: row.status,
      error: row.error || '',
      actorName: row.actorName || '',
      createdAt: row.createdAt,
    })),
  });
}

async function sendOne(to: string, subject: string, body: string) {
  const { html, text } = composeBodies(subject, body);
  return sendMail({ to, subject, html, text });
}

export async function sendAdminMail(req: Request, res: Response) {
  if (!isEmailConfigured()) {
    res.status(503).json({ success: false, error: 'SMTP is not configured. Add SMTP_HOST and EMAIL_FROM.' });
    return;
  }
  const to = String(req.body?.to || '').trim().toLowerCase();
  const subject = String(req.body?.subject || '').trim().slice(0, 180);
  const body = String(req.body?.body || '').trim().slice(0, 12_000);
  if (!EMAIL_RE.test(to) || !subject || !body) {
    res.status(400).json({ success: false, error: 'To, subject, and message are required.' });
    return;
  }
  const actor = actorFromReq(req);
  try {
    const ok = await sendOne(to, subject, body);
    await OutboundMail.create({
      to,
      subject,
      body,
      audience: 'one',
      status: ok ? 'sent' : 'failed',
      error: ok ? '' : 'Send failed',
      actorName: actor.name,
    });
    if (!ok) {
      res.status(502).json({ success: false, error: 'Could not send this email.' });
      return;
    }
    recordAdminAudit(req, {
      action: 'create',
      entity: 'mail',
      summary: `${actor.name} sent mail to ${to}: ${subject}`,
    });
    res.json({ success: true });
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Could not send this email.';
    res.status(502).json({ success: false, error: message });
  }
}

export async function sendBulkMail(req: Request, res: Response) {
  if (!isEmailConfigured()) {
    res.status(503).json({ success: false, error: 'SMTP is not configured. Add SMTP_HOST and EMAIL_FROM.' });
    return;
  }
  const audience = String(req.body?.audience || 'custom');
  const subject = String(req.body?.subject || '').trim().slice(0, 180);
  const body = String(req.body?.body || '').trim().slice(0, 12_000);
  if (!subject || !body) {
    res.status(400).json({ success: false, error: 'Subject and message are required.' });
    return;
  }

  let recipients: string[] = [];
  if (audience === 'leads') {
    const leads = await Lead.find({ email: { $nin: [null, ''] } }).select('email').limit(MAX_BULK).lean();
    recipients = [...new Set(leads.map((row) => String(row.email || '').toLowerCase()).filter((email) => EMAIL_RE.test(email)))];
  } else if (audience === 'users') {
    const users = await Candidate.find().select('email').limit(MAX_BULK).lean();
    recipients = [...new Set(users.map((row) => String(row.email || '').toLowerCase()).filter((email) => EMAIL_RE.test(email)))];
  } else {
    recipients = parseEmails(String(req.body?.emails || ''));
  }

  if (recipients.length === 0) {
    res.status(400).json({ success: false, error: 'No valid email addresses in this audience.' });
    return;
  }

  const actor = actorFromReq(req);
  let sent = 0;
  let failed = 0;
  for (const to of recipients) {
    try {
      const ok = await sendOne(to, subject, body);
      await OutboundMail.create({
        to,
        subject,
        body,
        audience: audience === 'leads' || audience === 'users' ? audience : 'custom',
        status: ok ? 'sent' : 'failed',
        error: ok ? '' : 'Send failed',
        actorName: actor.name,
      });
      if (ok) sent += 1;
      else failed += 1;
    } catch (error) {
      failed += 1;
      await OutboundMail.create({
        to,
        subject,
        body,
        audience: audience === 'leads' || audience === 'users' ? audience : 'custom',
        status: 'failed',
        error: error instanceof Error ? error.message.slice(0, 180) : 'Send failed',
        actorName: actor.name,
      });
    }
  }

  recordAdminAudit(req, {
    action: 'create',
    entity: 'mail',
    summary: `${actor.name} sent bulk mail (${audience}) to ${sent} addresses: ${subject}`,
    details: { sent, failed, audience },
  });

  res.json({ success: true, sent, failed, total: recipients.length });
}
